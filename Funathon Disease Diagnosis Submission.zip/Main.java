public class Main {
static Frame frame = new Frame();
public static void main(String[] args){
    }
}
